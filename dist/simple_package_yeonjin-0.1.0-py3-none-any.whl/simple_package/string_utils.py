def reverse_string(s):
    """문자열을 뒤집습니다"""
    return s[::-1]