from setuptools import setup, find_packages
# import os
# from dotenv import load_dotenv

# # .env 파일 로드
# load_dotenv()

# # 환경 변수 가져오기
# username = os.getenv("PYPI_USERNAME")
# password = os.getenv("PYPI_PASSWORD")

# # twine 명령 실행
# os.system(f"twine upload dist/* -u {username} -p {password}")

setup(
    name="simple_package",
    version="0.1.0",
    packages=find_packages(),
    description="A simple package for reversing strings",
    author="yeonjin",
    author_email="yeonjin917n.n@gmail.com",
    url="https://github.com/kangyeonjin/simple_package.git",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)