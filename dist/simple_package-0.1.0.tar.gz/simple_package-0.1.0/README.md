# My Simple Package

이 패키지는 문자열을 뒤집는 간단한 함수를 제공합니다.

## 설치

pip install simple_package

## 사용법
```python
from my_simple_package import reverse_string

print(reverse_string("hello")) 